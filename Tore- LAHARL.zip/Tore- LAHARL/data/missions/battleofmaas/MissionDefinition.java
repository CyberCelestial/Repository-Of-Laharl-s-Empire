package data.missions.battleofmaas;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

public class MissionDefinition implements MissionDefinitionPlugin {

	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets
		api.initFleet(FleetSide.PLAYER, "Your Ship", FleetGoal.ATTACK, false);
		api.initFleet(FleetSide.ENEMY, "TTS Fleet", FleetGoal.ATTACK, true);

		// Set a blurb for each fleet
		api.setFleetTagline(FleetSide.PLAYER, "Maas Station Defenses");
		api.setFleetTagline(FleetSide.ENEMY, "TTS Fleet");

		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("Engage and destroy all TTS ships");
		api.addBriefingItem("Keep your ships in one piece");
		api.addBriefingItem("Protect the ISS Horizon");
		
	
		// Set up the player's fleet
		api.addToFleet(FleetSide.PLAYER, "damocles_Basic", FleetMemberType.SHIP, "The Damocles", true);
		api.addToFleet(FleetSide.PLAYER, "mace_Basic", FleetMemberType.SHIP, "ISS Horizon", false);
		api.addToFleet(FleetSide.PLAYER, "foxhound_Basic", FleetMemberType.SHIP, "The Foxhound", false);
		api.addToFleet(FleetSide.PLAYER, "talus_Basic", FleetMemberType.SHIP, "ISS Chartreuse", false);
		api.addToFleet(FleetSide.PLAYER, "talus_Assault", FleetMemberType.SHIP, "The Vengeance", false);
		api.addToFleet(FleetSide.PLAYER, "hawkmk2_Assault", FleetMemberType.SHIP, "Station Defense Corvette", false);
		api.addToFleet(FleetSide.PLAYER, "sentinelmk2_Support", FleetMemberType.SHIP, "Station Defense Frigate", false);

		// Mark player flagship as essential
		api.defeatOnShipLoss("The Damocles");
		api.defeatOnShipLoss("The Foxhound");
		api.defeatOnShipLoss("The Vengeance");
		api.defeatOnShipLoss("ISS Horizon");

		// Set up the enemy fleet
		api.addToFleet(FleetSide.ENEMY, "aurora_Balanced", FleetMemberType.SHIP, "TTS Fleet Captain", false);
		api.addToFleet(FleetSide.ENEMY, "medusa_CS", FleetMemberType.SHIP, "TTS Escort", false);
//		api.addToFleet(FleetSide.ENEMY, "medusa_CS", FleetMemberType.SHIP, "TTS Escort", false);
		api.addToFleet(FleetSide.ENEMY, "wolf_Strike", FleetMemberType.SHIP, "TTS Escort", false);
		api.addToFleet(FleetSide.ENEMY, "wolf_Strike", FleetMemberType.SHIP, "TTS Escort", false);
		api.addToFleet(FleetSide.ENEMY, "tempest_Attack", FleetMemberType.SHIP, "TTS Escort", false);
//		api.addToFleet(FleetSide.ENEMY, "tempest_Attack", FleetMemberType.SHIP, "TTS Escort", false);


		// Set up the map.
		float width = 5000f;
		float height = 5000f;
		api.initMap((float)-width/1f, (float)width/1f, (float)-height/1f, (float)height/1f);
		
		float minX = -width/1;
		float minY = -height/1;
		
		api.addPlanet(minX + width * 0.95f, minY + height * 0.4f, 400f, "barren", 400f);

		api.addObjective(minX + width * 0.9f, minY + height * 0.3f, "sensor_array");
		api.addObjective(minX + width * 1.0f, minY + height * 0.3f, "nav_buoy");

		api.addAsteroidField(minX + width/2f, minY + height/2f, 0, 5000f,
								20f, 40f, 75);

	}

}
