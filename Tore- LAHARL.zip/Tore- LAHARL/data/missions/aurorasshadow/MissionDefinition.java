package data.missions.aurorasshadow;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

public class MissionDefinition implements MissionDefinitionPlugin {

	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets
		api.initFleet(FleetSide.PLAYER, "Your Ship", FleetGoal.ATTACK, true, 5);
		api.initFleet(FleetSide.ENEMY, "Pirates", FleetGoal.ATTACK, true, 5);

		// Set a blurb for each fleet
		api.setFleetTagline(FleetSide.PLAYER, "ISS Horizon Taskforce");
		api.setFleetTagline(FleetSide.ENEMY, "Pirates");

		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("Destroy the pirates");
		api.addBriefingItem("Keep your ship in one piece");
		api.addBriefingItem("Protect the ISS Chartreuse");
		api.addBriefingItem("Protect the ISS Horizon");
		
	
		// Set up the player's fleet
		api.addToFleet(FleetSide.PLAYER, "foxhound_Basic", FleetMemberType.SHIP, "The Foxhound", true);
		api.addToFleet(FleetSide.PLAYER, "mace_Basic", FleetMemberType.SHIP, "ISS Horizon", false);
		api.addToFleet(FleetSide.PLAYER, "tarsus_Standard", FleetMemberType.SHIP, "ISS Chartreuse", false);
		api.addToFleet(FleetSide.PLAYER, "striker_Assault", FleetMemberType.SHIP, "Salvaged Pirate Ship", false);

		// Mark player flagship as essential
		api.defeatOnShipLoss("The Foxhound");
		api.defeatOnShipLoss("ISS Chartreuse");
		api.defeatOnShipLoss("ISS Horizon");

		// Set up the enemy fleet
		api.addToFleet(FleetSide.ENEMY, "condor_Support", FleetMemberType.SHIP, "Lost Fortunes", false).getCaptain().setPersonality(Personalities.AGGRESSIVE);
		api.addToFleet(FleetSide.ENEMY, "lasher_Standard", FleetMemberType.SHIP, "Pirate Escort", false).getCaptain().setPersonality(Personalities.AGGRESSIVE);
		api.addToFleet(FleetSide.ENEMY, "hound_Standard", FleetMemberType.SHIP, "Pirate Escort", false).getCaptain().setPersonality(Personalities.AGGRESSIVE);

		// Set up the map.
		float width = 5000f;
		float height = 5000f;
		api.initMap((float)-width/1f, (float)width/1f, (float)-height/1f, (float)height/1f);
		
		float minX = -width/1;
		float minY = -height/1;
		

		api.addPlanet(minX + width * 0.8f, minY + height * 0.5f, 800f, "barren", 800f);

	}

}
