package data.missions.settingsail;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;

public class MissionDefinition implements MissionDefinitionPlugin {

	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets
		api.initFleet(FleetSide.PLAYER, "Your Ship", FleetGoal.ATTACK, false);
		api.initFleet(FleetSide.ENEMY, "Practice Drones", FleetGoal.ATTACK, true, 5);

		// Set a blurb for each fleet
		api.setFleetTagline(FleetSide.PLAYER, "The Foxhound");
		api.setFleetTagline(FleetSide.ENEMY, "Practice Drones");

		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("Destroy the drones");
		api.addBriefingItem("Keep your ship in one piece");
		
	
		// Set up the player's fleet
		api.addToFleet(FleetSide.PLAYER, "foxhound_Basic", FleetMemberType.SHIP, "The Foxhound", true);	

		// Mark player flagship as essential
		api.defeatOnShipLoss("The Foxhound");

		// Set up the enemy fleet
		api.addToFleet(FleetSide.ENEMY, "picket_Assault", FleetMemberType.SHIP, "Practice Drone Alpha", false).getCaptain().setPersonality(Personalities.RECKLESS);
		api.addToFleet(FleetSide.ENEMY, "picket_Assault", FleetMemberType.SHIP, "Practice Drone Bravo", false).getCaptain().setPersonality(Personalities.RECKLESS);
		api.addToFleet(FleetSide.ENEMY, "picket_Assault", FleetMemberType.SHIP, "Practice Drone Charlie", false).getCaptain().setPersonality(Personalities.RECKLESS);

		// Set up the map.
		float width = 5000f;
		float height = 5000f;
		api.initMap((float)-width/1f, (float)width/1f, (float)-height/1f, (float)height/1f);
		
		float minX = -width/1;
		float minY = -height/1;

		api.addPlanet(minX + width * 0.95f, minY + height * 0.4f, 400f, "barren", 400f);

		api.addObjective(minX + width * 0.9f, minY + height * 0.3f, "sensor_array");
		api.addObjective(minX + width * 1.0f, minY + height * 0.3f, "nav_buoy");

		api.addAsteroidField(minX + width/2f, minY + height/2f, 0, 5000f,
								20f, 40f, 75);
		
	}

}
