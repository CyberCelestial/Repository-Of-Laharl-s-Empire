package data.missions.tupcollection;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

public class MissionDefinition implements MissionDefinitionPlugin {

	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets
		api.initFleet(FleetSide.PLAYER, "Tore Up Plenty", FleetGoal.ATTACK, false, 10);
		api.initFleet(FleetSide.ENEMY, "TARGETS", FleetGoal.ATTACK, true, 10);

		// Set a blurb for each fleet
		api.setFleetTagline(FleetSide.PLAYER, "Tore Up Plenty");
		api.setFleetTagline(FleetSide.ENEMY, "Targets");

		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("Destroy all targets");
		
	
		// Set up the player's fleet
		api.addToFleet(FleetSide.PLAYER, "eventhorizon_Basic", FleetMemberType.SHIP, "Event Horizon", true);
		api.addToFleet(FleetSide.PLAYER, "eventhorizon_Assault", FleetMemberType.SHIP, "Event Horizon", true);
		api.addToFleet(FleetSide.PLAYER, "overlord_Basic", FleetMemberType.SHIP, "Overlord", true);
		api.addToFleet(FleetSide.PLAYER, "overlord_Assault", FleetMemberType.SHIP, "Overlord", true);
		api.addToFleet(FleetSide.PLAYER, "overlord_Support", FleetMemberType.SHIP, "Overlord", true);
		api.addToFleet(FleetSide.PLAYER, "dreadnought_Basic", FleetMemberType.SHIP, "Dreadnought", true);
		api.addToFleet(FleetSide.PLAYER, "dreadnought_Assault", FleetMemberType.SHIP, "Dreadnought", true);
		api.addToFleet(FleetSide.PLAYER, "dreadnought_Support", FleetMemberType.SHIP, "Dreadnought", true);
		api.addToFleet(FleetSide.PLAYER, "cormorant_Basic", FleetMemberType.SHIP, "Cormorant", true);
		api.addToFleet(FleetSide.PLAYER, "cormorant_Assault", FleetMemberType.SHIP, "Cormorant", true);
		api.addToFleet(FleetSide.PLAYER, "cormorant_Support", FleetMemberType.SHIP, "Cormorant", true);
		api.addToFleet(FleetSide.PLAYER, "zephyr_Basic", FleetMemberType.SHIP, "Zephyr", true);
		api.addToFleet(FleetSide.PLAYER, "zephyr_Assault", FleetMemberType.SHIP, "Zephyr", true);
		api.addToFleet(FleetSide.PLAYER, "zephyr_Support", FleetMemberType.SHIP, "Zephyr", true);
		api.addToFleet(FleetSide.PLAYER, "centaur_Basic", FleetMemberType.SHIP, "Centaur", true);
		api.addToFleet(FleetSide.PLAYER, "centaur_Assault", FleetMemberType.SHIP, "Centaur", true);
		api.addToFleet(FleetSide.PLAYER, "centaur_Support", FleetMemberType.SHIP, "Centaur", true);
		api.addToFleet(FleetSide.PLAYER, "perigee_Basic", FleetMemberType.SHIP, "Perigee", true);
		api.addToFleet(FleetSide.PLAYER, "perigee_Assault", FleetMemberType.SHIP, "Perigee", true);
		api.addToFleet(FleetSide.PLAYER, "perigee_Support", FleetMemberType.SHIP, "Perigee", true);
		api.addToFleet(FleetSide.PLAYER, "taskmaster_Basic", FleetMemberType.SHIP, "Taskmaster", true);
		api.addToFleet(FleetSide.PLAYER, "taskmaster_Assault", FleetMemberType.SHIP, "Taskmaster", true);
		api.addToFleet(FleetSide.PLAYER, "taskmaster_Support", FleetMemberType.SHIP, "Taskmaster", true);
		api.addToFleet(FleetSide.PLAYER, "stampede_Basic", FleetMemberType.SHIP, "Stampede", true);
		api.addToFleet(FleetSide.PLAYER, "stampede_Assault", FleetMemberType.SHIP, "Stampede", true);
		api.addToFleet(FleetSide.PLAYER, "stampede_Support", FleetMemberType.SHIP, "Stampede", true);
		api.addToFleet(FleetSide.PLAYER, "damocles_Basic", FleetMemberType.SHIP, "Damocles", true);
		api.addToFleet(FleetSide.PLAYER, "damocles_Assault", FleetMemberType.SHIP, "Damocles", true);
		api.addToFleet(FleetSide.PLAYER, "damocles_Support", FleetMemberType.SHIP, "Damocles", true);
		api.addToFleet(FleetSide.PLAYER, "annihilatormk2_Basic", FleetMemberType.SHIP, "Annihilator Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "annihilatormk2_Assault", FleetMemberType.SHIP, "Annihilator Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "annihilatormk2_Support", FleetMemberType.SHIP, "Annihilator Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "mace_Basic", FleetMemberType.SHIP, "Mace", true);
		api.addToFleet(FleetSide.PLAYER, "mace_Assault", FleetMemberType.SHIP, "Mace", true);
		api.addToFleet(FleetSide.PLAYER, "mace_Support", FleetMemberType.SHIP, "Mace", true);
		api.addToFleet(FleetSide.PLAYER, "phoenix_Basic", FleetMemberType.SHIP, "Phoenix", true);
		api.addToFleet(FleetSide.PLAYER, "phoenix_Assault", FleetMemberType.SHIP, "Phoenix", true);
		api.addToFleet(FleetSide.PLAYER, "phoenix_Support", FleetMemberType.SHIP, "Phoenix", true);
		api.addToFleet(FleetSide.PLAYER, "lance_Basic", FleetMemberType.SHIP, "Lance", true);
		api.addToFleet(FleetSide.PLAYER, "lance_Assault", FleetMemberType.SHIP, "Lance", true);
		api.addToFleet(FleetSide.PLAYER, "lance_Support", FleetMemberType.SHIP, "Lance", true);
		api.addToFleet(FleetSide.PLAYER, "rover_Basic", FleetMemberType.SHIP, "Rover", true);
		api.addToFleet(FleetSide.PLAYER, "rover_Assault", FleetMemberType.SHIP, "Rover", true);
		api.addToFleet(FleetSide.PLAYER, "rover_Support", FleetMemberType.SHIP, "Rover", true);
		api.addToFleet(FleetSide.PLAYER, "buzzard_Basic", FleetMemberType.SHIP, "Buzzard", true);
		api.addToFleet(FleetSide.PLAYER, "buzzard_Assault", FleetMemberType.SHIP, "Buzzard", true);
		api.addToFleet(FleetSide.PLAYER, "buzzard_Support", FleetMemberType.SHIP, "Buzzard", true);
		api.addToFleet(FleetSide.PLAYER, "jules_Basic", FleetMemberType.SHIP, "Jules", true);
		api.addToFleet(FleetSide.PLAYER, "jules_Assault", FleetMemberType.SHIP, "Jules", true);
		api.addToFleet(FleetSide.PLAYER, "jules_Support", FleetMemberType.SHIP, "Jules", true);
		api.addToFleet(FleetSide.PLAYER, "daedalus_Basic", FleetMemberType.SHIP, "Daedalus", true);
		api.addToFleet(FleetSide.PLAYER, "daedalus_Assault", FleetMemberType.SHIP, "Daedalus", true);
		api.addToFleet(FleetSide.PLAYER, "daedalus_Support", FleetMemberType.SHIP, "Daedalus", true);
		api.addToFleet(FleetSide.PLAYER, "barracuda_Basic", FleetMemberType.SHIP, "Barracuda", true);
		api.addToFleet(FleetSide.PLAYER, "barracuda_Assault", FleetMemberType.SHIP, "Barracuda", true);
		api.addToFleet(FleetSide.PLAYER, "barracuda_Support", FleetMemberType.SHIP, "Barracuda", true);
		api.addToFleet(FleetSide.PLAYER, "annihilator_Basic", FleetMemberType.SHIP, "Annihilator", true);
		api.addToFleet(FleetSide.PLAYER, "annihilator_Assault", FleetMemberType.SHIP, "Annihilator", true);
		api.addToFleet(FleetSide.PLAYER, "annihilator_Support", FleetMemberType.SHIP, "Annihilator", true);
		api.addToFleet(FleetSide.PLAYER, "hedgehog_Basic", FleetMemberType.SHIP, "Hedgehog", true);
		api.addToFleet(FleetSide.PLAYER, "hedgehog_Assault", FleetMemberType.SHIP, "Hedgehog", true);
		api.addToFleet(FleetSide.PLAYER, "hedgehog_Support", FleetMemberType.SHIP, "Hedgehog", true);
		api.addToFleet(FleetSide.PLAYER, "void_Basic", FleetMemberType.SHIP, "Void", true);
		api.addToFleet(FleetSide.PLAYER, "void_Assault", FleetMemberType.SHIP, "Void", true);
		api.addToFleet(FleetSide.PLAYER, "void_Support", FleetMemberType.SHIP, "Void", true);
		api.addToFleet(FleetSide.PLAYER, "rurhland_p_Basic", FleetMemberType.SHIP, "Wildeberest", true);
		api.addToFleet(FleetSide.PLAYER, "wildebeest_Basic", FleetMemberType.SHIP, "Wildebeest", true);
		api.addToFleet(FleetSide.PLAYER, "wildebeest_Assault", FleetMemberType.SHIP, "Wildebeest", true);
		api.addToFleet(FleetSide.PLAYER, "wildebeest_Support", FleetMemberType.SHIP, "Wildebeest", true);
		api.addToFleet(FleetSide.PLAYER, "rurhland_Basic", FleetMemberType.SHIP, "Wilderbeest", true);
		api.addToFleet(FleetSide.PLAYER, "rurhland_Assault", FleetMemberType.SHIP, "Wilderbeest", true);
		api.addToFleet(FleetSide.PLAYER, "rurhland_Support", FleetMemberType.SHIP, "Wilderbeest", true);
		api.addToFleet(FleetSide.PLAYER, "hermit_Basic", FleetMemberType.SHIP, "Hermit", true);
		api.addToFleet(FleetSide.PLAYER, "hermit_Assault", FleetMemberType.SHIP, "Hermit", true);
		api.addToFleet(FleetSide.PLAYER, "hermit_Support", FleetMemberType.SHIP, "Hermit", true);
		api.addToFleet(FleetSide.PLAYER, "talus_Basic", FleetMemberType.SHIP, "Talus", true);
		api.addToFleet(FleetSide.PLAYER, "talus_Assault", FleetMemberType.SHIP, "Talus", true);
		api.addToFleet(FleetSide.PLAYER, "talus_Support", FleetMemberType.SHIP, "Talus", true);
		api.addToFleet(FleetSide.PLAYER, "marshall_Basic", FleetMemberType.SHIP, "Marshall", true);
		api.addToFleet(FleetSide.PLAYER, "marshall_Assault", FleetMemberType.SHIP, "Marshall", true);
		api.addToFleet(FleetSide.PLAYER, "marshall_Support", FleetMemberType.SHIP, "Marshall", true);
		api.addToFleet(FleetSide.PLAYER, "buckmk2_Basic", FleetMemberType.SHIP, "Buck Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "buckmk2_Assault", FleetMemberType.SHIP, "Buck Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "buckmk2_Support", FleetMemberType.SHIP, "Buck Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "buck_Basic", FleetMemberType.SHIP, "Buck", true);
		api.addToFleet(FleetSide.PLAYER, "buck_Assault", FleetMemberType.SHIP, "Buck", true);
		api.addToFleet(FleetSide.PLAYER, "buck_Support", FleetMemberType.SHIP, "Buck", true);
		api.addToFleet(FleetSide.PLAYER, "innogen_Basic", FleetMemberType.SHIP, "Buck", true);
		api.addToFleet(FleetSide.PLAYER, "innogen_Assault", FleetMemberType.SHIP, "Buck", true);
		api.addToFleet(FleetSide.PLAYER, "innogen_Support", FleetMemberType.SHIP, "Buck", true);
		api.addToFleet(FleetSide.PLAYER, "moth_Basic", FleetMemberType.SHIP, "Moth", true);
		api.addToFleet(FleetSide.PLAYER, "moth_Assault", FleetMemberType.SHIP, "Moth", true);
		api.addToFleet(FleetSide.PLAYER, "moth_Support", FleetMemberType.SHIP, "Moth", true);
		api.addToFleet(FleetSide.PLAYER, "ryker_Basic", FleetMemberType.SHIP, "Ryker", true);
		api.addToFleet(FleetSide.PLAYER, "ryker_Assault", FleetMemberType.SHIP, "Ryker", true);
		api.addToFleet(FleetSide.PLAYER, "ryker_Support", FleetMemberType.SHIP, "Ryker", true);
		api.addToFleet(FleetSide.PLAYER, "thunderchild_Basic", FleetMemberType.SHIP, "Thunderchild", true);
		api.addToFleet(FleetSide.PLAYER, "thunderchild_Assault", FleetMemberType.SHIP, "Thunderchild", true);
		api.addToFleet(FleetSide.PLAYER, "thunderchild_Support", FleetMemberType.SHIP, "Thunderchild", true);
		api.addToFleet(FleetSide.PLAYER, "icarus_Basic", FleetMemberType.SHIP, "Icarus", true);
		api.addToFleet(FleetSide.PLAYER, "icarus_Assault", FleetMemberType.SHIP, "Icarus", true);
		api.addToFleet(FleetSide.PLAYER, "icarus_Support", FleetMemberType.SHIP, "Icarus", true);
		api.addToFleet(FleetSide.PLAYER, "owen_Basic", FleetMemberType.SHIP, "Owen", true);
		api.addToFleet(FleetSide.PLAYER, "owen_Assault", FleetMemberType.SHIP, "Owen", true);
		api.addToFleet(FleetSide.PLAYER, "owen_Support", FleetMemberType.SHIP, "Owen", true);
		api.addToFleet(FleetSide.PLAYER, "sentinelmk2_Basic", FleetMemberType.SHIP, "Sentinel Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "sentinelmk2_Assault", FleetMemberType.SHIP, "Sentinel Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "sentinelmk2_Support", FleetMemberType.SHIP, "Sentinel Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "sentinel_Basic", FleetMemberType.SHIP, "Sentinel", true);
		api.addToFleet(FleetSide.PLAYER, "sentinel_Assault", FleetMemberType.SHIP, "Sentinel", true);
		api.addToFleet(FleetSide.PLAYER, "sentinel_Support", FleetMemberType.SHIP, "Sentinel", true);
		api.addToFleet(FleetSide.PLAYER, "strikermk2_Basic", FleetMemberType.SHIP, "Striker Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "strikermk2_Assault", FleetMemberType.SHIP, "Striker Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "strikermk2_Support", FleetMemberType.SHIP, "Striker Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "striker_Basic", FleetMemberType.SHIP, "Striker", true);
		api.addToFleet(FleetSide.PLAYER, "striker_Assault", FleetMemberType.SHIP, "Striker", true);
		api.addToFleet(FleetSide.PLAYER, "striker_Support", FleetMemberType.SHIP, "Striker", true);
		api.addToFleet(FleetSide.PLAYER, "timberwolfmk2_Basic", FleetMemberType.SHIP, "Timberwolf Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "timberwolfmk2_Assault", FleetMemberType.SHIP, "Timberwolf Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "timberwolfmk2_Support", FleetMemberType.SHIP, "Timberwolf Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "timberwolf_Basic", FleetMemberType.SHIP, "Timberwolf", true);
		api.addToFleet(FleetSide.PLAYER, "timberwolf_Assault", FleetMemberType.SHIP, "Timberwolf", true);
		api.addToFleet(FleetSide.PLAYER, "timberwolf_Support", FleetMemberType.SHIP, "Timberwolf", true);
		api.addToFleet(FleetSide.PLAYER, "wrestlermk2_Basic", FleetMemberType.SHIP, "Wrestler Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "wrestlermk2_Assault", FleetMemberType.SHIP, "Wrestler Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "wrestlermk2_Support", FleetMemberType.SHIP, "Wrestler Mk2", true);
		api.addToFleet(FleetSide.PLAYER, "wrestler_Basic", FleetMemberType.SHIP, "Wrestler", true);
		api.addToFleet(FleetSide.PLAYER, "wrestler_Assault", FleetMemberType.SHIP, "Wrestler", true);
		api.addToFleet(FleetSide.PLAYER, "wrestler_Support", FleetMemberType.SHIP, "Wrestler", true);
		api.addToFleet(FleetSide.PLAYER, "sojourner_Basic", FleetMemberType.SHIP, "Wrestler", true);
		api.addToFleet(FleetSide.PLAYER, "sojourner_Assault", FleetMemberType.SHIP, "Wrestler", true);
		api.addToFleet(FleetSide.PLAYER, "sojourner_Support", FleetMemberType.SHIP, "Wrestler", true);
		api.addToFleet(FleetSide.PLAYER, "platypus_Basic", FleetMemberType.SHIP, "Platypus", true);
		api.addToFleet(FleetSide.PLAYER, "platypus_Assault", FleetMemberType.SHIP, "Platypus", true);
		api.addToFleet(FleetSide.PLAYER, "platypus_Support", FleetMemberType.SHIP, "Platypus", true);
		api.addToFleet(FleetSide.PLAYER, "redstar_Basic", FleetMemberType.SHIP, "Redstar", true);
		api.addToFleet(FleetSide.PLAYER, "redstar_Assault", FleetMemberType.SHIP, "Redstar", true);
		api.addToFleet(FleetSide.PLAYER, "redstar_Support", FleetMemberType.SHIP, "Redstar", true);
		api.addToFleet(FleetSide.PLAYER, "wolfpack_Basic", FleetMemberType.SHIP, "Wolfpack", true);
		api.addToFleet(FleetSide.PLAYER, "wolfpack_Assault", FleetMemberType.SHIP, "Wolfpack", true);
		api.addToFleet(FleetSide.PLAYER, "wolfpack_Support", FleetMemberType.SHIP, "Wolfpack", true);
		api.addToFleet(FleetSide.PLAYER, "bloodhound_Basic", FleetMemberType.SHIP, "Bloodhound", true);
		api.addToFleet(FleetSide.PLAYER, "bloodhound_Assault", FleetMemberType.SHIP, "Bloodhound", true);
		api.addToFleet(FleetSide.PLAYER, "bloodhound_Support", FleetMemberType.SHIP, "Bloodhound", true);
		api.addToFleet(FleetSide.PLAYER, "foxhound_Basic", FleetMemberType.SHIP, "Foxhound", true);
		api.addToFleet(FleetSide.PLAYER, "foxhound_Assault", FleetMemberType.SHIP, "Foxhound", true);
		api.addToFleet(FleetSide.PLAYER, "foxhound_Support", FleetMemberType.SHIP, "Foxhound", true);
		api.addToFleet(FleetSide.PLAYER, "skylarke_Basic", FleetMemberType.SHIP, "Skylark SE", true);
		api.addToFleet(FleetSide.PLAYER, "skylarke_Assault", FleetMemberType.SHIP, "Skylark SE", true);
		api.addToFleet(FleetSide.PLAYER, "skylarke_Support", FleetMemberType.SHIP, "Skylark SE", true);
		api.addToFleet(FleetSide.PLAYER, "skylarkf_Basic", FleetMemberType.SHIP, "Skylark SF", true);
		api.addToFleet(FleetSide.PLAYER, "skylarkf_Assault", FleetMemberType.SHIP, "Skylark SF", true);
		api.addToFleet(FleetSide.PLAYER, "skylarkf_Support", FleetMemberType.SHIP, "Skylark SF", true);
		api.addToFleet(FleetSide.PLAYER, "skylarkc_Basic", FleetMemberType.SHIP, "Skylark SC", true);
		api.addToFleet(FleetSide.PLAYER, "skylarkc_Assault", FleetMemberType.SHIP, "Skylark SC", true);
		api.addToFleet(FleetSide.PLAYER, "skylarkc_Support", FleetMemberType.SHIP, "Skylark SC", true);
		api.addToFleet(FleetSide.PLAYER, "underdog_Basic", FleetMemberType.SHIP, "Underdog", true);
		api.addToFleet(FleetSide.PLAYER, "underdog_Assault", FleetMemberType.SHIP, "Underdog", true);
		api.addToFleet(FleetSide.PLAYER, "underdog_Support", FleetMemberType.SHIP, "Underdog", true);
		api.addToFleet(FleetSide.PLAYER, "hawkmk2_Basic", FleetMemberType.SHIP, "Hawk Ranger", true);
		api.addToFleet(FleetSide.PLAYER, "hawkmk2_Assault", FleetMemberType.SHIP, "Hawk Ranger", true);
		api.addToFleet(FleetSide.PLAYER, "hawkmk2_Support", FleetMemberType.SHIP, "Hawk Ranger", true);
		api.addToFleet(FleetSide.PLAYER, "steer_Utility", FleetMemberType.SHIP, "Steer", true);

		// Mark player flagship as essential

		// Set up the enemy fleet
		api.addToFleet(FleetSide.ENEMY, "onslaught_Outdated", FleetMemberType.SHIP, "Onslaught I", false);
		api.addToFleet(FleetSide.ENEMY, "onslaught_Outdated", FleetMemberType.SHIP, "Onslaught II", false);
		api.addToFleet(FleetSide.ENEMY, "onslaught_Outdated", FleetMemberType.SHIP, "Onslaught III", false);
		api.addToFleet(FleetSide.ENEMY, "dominator_Support", FleetMemberType.SHIP, "Dominator I", false);
		api.addToFleet(FleetSide.ENEMY, "dominator_Outdated", FleetMemberType.SHIP, "Dominator II", false);
		api.addToFleet(FleetSide.ENEMY, "dominator_Assault", FleetMemberType.SHIP, "Dominator III", false);
		api.addToFleet(FleetSide.ENEMY, "condor_Support", FleetMemberType.SHIP, "Condor I", false);
		api.addToFleet(FleetSide.ENEMY, "condor_Support", FleetMemberType.SHIP, "Condor II", false);
		api.addToFleet(FleetSide.ENEMY, "condor_Support", FleetMemberType.SHIP, "Condor III", false);
		api.addToFleet(FleetSide.ENEMY, "condor_Support", FleetMemberType.SHIP, "Condor IV", false);
		api.addToFleet(FleetSide.ENEMY, "enforcer_Assault", FleetMemberType.SHIP, "Enforcer I", false);
		api.addToFleet(FleetSide.ENEMY, "enforcer_Balanced", FleetMemberType.SHIP, "Enforcer II", false);
		api.addToFleet(FleetSide.ENEMY, "enforcer_Elite", FleetMemberType.SHIP, "Enforcer III", false);
		api.addToFleet(FleetSide.ENEMY, "enforcer_Elite", FleetMemberType.SHIP, "Enforcer IV", false);
		api.addToFleet(FleetSide.ENEMY, "lasher_Strike", FleetMemberType.SHIP, "Lasher I", false);
		api.addToFleet(FleetSide.ENEMY, "lasher_Standard", FleetMemberType.SHIP, "Lasher II", false);
		api.addToFleet(FleetSide.ENEMY, "lasher_Assault", FleetMemberType.SHIP, "Lasher III", false);
		api.addToFleet(FleetSide.ENEMY, "lasher_Assault", FleetMemberType.SHIP, "Lasher IV", false);
		api.addToFleet(FleetSide.ENEMY, "lasher_Assault", FleetMemberType.SHIP, "Lasher V", false);
		api.addToFleet(FleetSide.ENEMY, "hound_Standard", FleetMemberType.SHIP, "Hound I", false);
		api.addToFleet(FleetSide.ENEMY, "hound_Standard", FleetMemberType.SHIP, "Hound II", false);
		api.addToFleet(FleetSide.ENEMY, "hound_Standard", FleetMemberType.SHIP, "Hound III", false);
		api.addToFleet(FleetSide.ENEMY, "hound_Standard", FleetMemberType.SHIP, "Hound IV", false);
		api.addToFleet(FleetSide.ENEMY, "hound_Standard", FleetMemberType.SHIP, "Hound V", false);
		api.addToFleet(FleetSide.ENEMY, "talon_wing", FleetMemberType.FIGHTER_WING, false);
		api.addToFleet(FleetSide.ENEMY, "talon_wing", FleetMemberType.FIGHTER_WING, false);
		api.addToFleet(FleetSide.ENEMY, "talon_wing", FleetMemberType.FIGHTER_WING, false);
		api.addToFleet(FleetSide.ENEMY, "talon_wing", FleetMemberType.FIGHTER_WING, false);
		api.addToFleet(FleetSide.ENEMY, "talon_wing", FleetMemberType.FIGHTER_WING, false);
		api.addToFleet(FleetSide.ENEMY, "piranha_wing", FleetMemberType.FIGHTER_WING, false);
		api.addToFleet(FleetSide.ENEMY, "piranha_wing", FleetMemberType.FIGHTER_WING, false);
		api.addToFleet(FleetSide.ENEMY, "piranha_wing", FleetMemberType.FIGHTER_WING, false);
		api.addToFleet(FleetSide.ENEMY, "piranha_wing", FleetMemberType.FIGHTER_WING, false);
		api.addToFleet(FleetSide.ENEMY, "piranha_wing", FleetMemberType.FIGHTER_WING, false);

		// Set up the map.
		float width = 5000f;
		float height = 5000f;
		api.initMap((float)-width/1f, (float)width/1f, (float)-height/1f, (float)height/1f);
		
		float minX = -width/1;
		float minY = -height/1;
		
		api.addNebula(minX + width * 0.2f, minY + height * 0.2f, 400);

		api.addNebula(minX + width * 0.6f, minY + height * 0.6f, 400);

		api.addNebula(minX + width * 1.0f, minY + height * 1.0f, 400);

		api.addNebula(minX + width * 1.4f, minY + height * 1.4f, 400);

		api.addNebula(minX + width * 1.8f, minY + height * 1.8f, 400);

		api.addObjective(minX + width * 0.6f, minY + height * 0.6f, "nav_buoy");
		api.addObjective(minX + width * 1.0f, minY + height * 1.0f, "comm_relay");
		api.addObjective(minX + width * 1.4f, minY + height * 1.4f, "sensor_array");

	}

}






