package data.missions.runningerrands;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;

public class MissionDefinition implements MissionDefinitionPlugin {

	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets
		api.initFleet(FleetSide.PLAYER, "Your Ship", FleetGoal.ATTACK, true, 5);
		api.initFleet(FleetSide.ENEMY, "Pirates", FleetGoal.ATTACK, true, 5);

		// Set a blurb for each fleet
		api.setFleetTagline(FleetSide.PLAYER, "ISS Chartreuse Escort");
		api.setFleetTagline(FleetSide.ENEMY, "Pirates");

		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("Destroy the pirates");
		api.addBriefingItem("Keep your ship in one piece");
		api.addBriefingItem("Protect the ISS Chartreuse");
		
	
		// Set up the player's fleet
		api.addToFleet(FleetSide.PLAYER, "foxhound_Basic", FleetMemberType.SHIP, "The Foxhound", true);
		api.addToFleet(FleetSide.PLAYER, "tarsus_Standard", FleetMemberType.SHIP, "ISS Chartreuse", false);
		api.addToFleet(FleetSide.PLAYER, "picket_Assault", FleetMemberType.SHIP, "Surplus Picket Drone", false).getCaptain().setPersonality(Personalities.RECKLESS);

		// Mark player flagship as essential
		api.defeatOnShipLoss("The Foxhound");
		api.defeatOnShipLoss("ISS Chartreuse");

		// Set up the enemy fleet
		api.addToFleet(FleetSide.ENEMY, "striker_Assault", FleetMemberType.SHIP, "Pirate Commandship", false);
		api.addToFleet(FleetSide.ENEMY, "lasher_Standard", FleetMemberType.SHIP, "Pirate Escort", false);

		// Set up the map.
		float width = 5000f;
		float height = 5000f;
		api.initMap((float)-width/1f, (float)width/1f, (float)-height/1f, (float)height/1f);
		
		float minX = -width/1;
		float minY = -height/1;
		
	}

}
