package data.missions.homecoming;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

public class MissionDefinition implements MissionDefinitionPlugin {

	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets
		api.initFleet(FleetSide.PLAYER, "Your Ship", FleetGoal.ATTACK, false);
		api.initFleet(FleetSide.ENEMY, "TTS Taskforce", FleetGoal.ATTACK, true);

		// Set a blurb for each fleet
		api.setFleetTagline(FleetSide.PLAYER, "Damocles Taskforce");
		api.setFleetTagline(FleetSide.ENEMY, "TTS Taskforce");

		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("Break through the blockade");
		api.addBriefingItem("Keep your ships in one piece");
		api.addBriefingItem("Protect mining freighter Alpha");
		
	
		// Set up the player's fleet
		api.addToFleet(FleetSide.PLAYER, "damocles_Basic", FleetMemberType.SHIP, "The Damocles", true);
		api.addToFleet(FleetSide.PLAYER, "foxhound_Basic", FleetMemberType.SHIP, "The Foxhound", false);
		api.addToFleet(FleetSide.PLAYER, "ryker_Basic", FleetMemberType.SHIP, "Captured Asteroid Cracker", false);
		api.addToFleet(FleetSide.PLAYER, "tarsus_Standard", FleetMemberType.SHIP, "Captured Mining Freighter Alpha", false);
		api.addToFleet(FleetSide.PLAYER, "tarsus_Standard", FleetMemberType.SHIP, "Captured Mining Freighter Beta", false);

		// Mark player flagship as essential
		api.defeatOnShipLoss("The Damocles");
		api.defeatOnShipLoss("The Foxhound");
		api.defeatOnShipLoss("Captured Mining Freighter Alpha");

		// Set up the enemy fleet
		api.addToFleet(FleetSide.ENEMY, "medusa_PD", FleetMemberType.SHIP, "TTS Taskforce Commander", false);
		api.addToFleet(FleetSide.ENEMY, "wolf_Strike", FleetMemberType.SHIP, "TTS Escort", false);
//		api.addToFleet(FleetSide.ENEMY, "tempest_Attack", FleetMemberType.SHIP, "TTS Escort", false);
		api.addToFleet(FleetSide.ENEMY, "brawler_tritachyon_Standard", FleetMemberType.SHIP, "TTS Escort", false);
//		api.addToFleet(FleetSide.ENEMY, "brawler_tritachyon_Standard", FleetMemberType.SHIP, "TTS Escort", false);


		// Set up the map.
		float width = 5000f;
		float height = 5000f;
		api.initMap((float)-width/1f, (float)width/1f, (float)-height/1f, (float)height/1f);
		
		float minX = -width/1;
		float minY = -height/1;
		
	}

}
