package data.missions.brokenavenue;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

public class MissionDefinition implements MissionDefinitionPlugin {

	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets
		api.initFleet(FleetSide.PLAYER, "Your Ship", FleetGoal.ATTACK, false);
		api.initFleet(FleetSide.ENEMY, "Unknown", FleetGoal.ATTACK, true);

		// Set a blurb for each fleet
		api.setFleetTagline(FleetSide.PLAYER, "Centaur Taskforce");
		api.setFleetTagline(FleetSide.ENEMY, "Unknown");

		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("Survive the avenue");
	
		// Set up the player's fleet
		api.addToFleet(FleetSide.PLAYER, "centaur_Basic", FleetMemberType.SHIP, "The Centaur", true);

		// Mark player flagship as essential
		api.defeatOnShipLoss("The Centaur");

		// Set up the enemy fleet
		api.addToFleet(FleetSide.ENEMY, "doom_Strike", FleetMemberType.SHIP, "Unknown Cruiser", false);
		api.addToFleet(FleetSide.ENEMY, "afflictor_d_pirates_Strike", FleetMemberType.SHIP, "Unknown Frigate", false);
		// Set up the map.
		float width = 7000f;
		float height = 7000f;
		api.initMap((float)-width/1f, (float)width/1f, (float)-height/1f, (float)height/1f);
		
		float minX = -width/1;
		float minY = -height/1;
		
		api.addAsteroidField(minX + width/1f, minY + height/1f, 0, 15000f,
								20f, 40f, 200);

		api.addNebula(minX + width * 0.3f, minY + height * 0.1f, 4000);
		api.addNebula(minX + width * 0.3f, minY + height * 0.5f, 4000);
		api.addNebula(minX + width * 0.3f, minY + height * 0.9f, 4000);
		api.addNebula(minX + width * 0.3f, minY + height * 1.3f, 4000);
		api.addNebula(minX + width * 0.3f, minY + height * 1.7f, 4000);
		api.addNebula(minX + width * 0.3f, minY + height * 0.1f, 4000);
		api.addNebula(minX + width * 1.7f, minY + height * 0.5f, 4000);
		api.addNebula(minX + width * 1.7f, minY + height * 0.9f, 4000);
		api.addNebula(minX + width * 1.7f, minY + height * 1.3f, 4000);
		api.addNebula(minX + width * 1.7f, minY + height * 1.7f, 4000);

	}

}
