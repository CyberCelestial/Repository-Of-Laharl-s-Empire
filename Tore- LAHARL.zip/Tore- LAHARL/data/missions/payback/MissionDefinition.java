package data.missions.payback;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

public class MissionDefinition implements MissionDefinitionPlugin {

	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets
		api.initFleet(FleetSide.PLAYER, "Your Ship", FleetGoal.ATTACK, false);
		api.initFleet(FleetSide.ENEMY, "Mining Outfit", FleetGoal.ATTACK, true);

		// Set a blurb for each fleet
		api.setFleetTagline(FleetSide.PLAYER, "Damocles Taskforce");
		api.setFleetTagline(FleetSide.ENEMY, "Maas Belt Mining Outfit");

		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("Destroy or disable Maas Mining Inc.");
		api.addBriefingItem("Keep your ships in one piece");
		api.addBriefingItem("Take care around those asteroid crackers!");
		
	
		// Set up the player's fleet
		api.addToFleet(FleetSide.PLAYER, "damocles_Basic", FleetMemberType.SHIP, "The Damocles", true);
		api.addToFleet(FleetSide.PLAYER, "foxhound_Basic", FleetMemberType.SHIP, "The Foxhound", false);
		api.addToFleet(FleetSide.PLAYER, "ryker_Basic", FleetMemberType.SHIP, "Captured Asteroid Cracker", false);
		api.addToFleet(FleetSide.PLAYER, "moth_Support", FleetMemberType.SHIP, "Captured Miner Escort", false);

		// Mark player flagship as essential
		api.defeatOnShipLoss("The Damocles");
		api.defeatOnShipLoss("The Foxhound");

		// Set up the enemy fleet
		api.addToFleet(FleetSide.ENEMY, "enforcer_Outdated", FleetMemberType.SHIP, "Mining Outfit Defender", false);
		api.addToFleet(FleetSide.ENEMY, "moth_Support", FleetMemberType.SHIP, "Mining Outfit Defender", false);
		api.addToFleet(FleetSide.ENEMY, "ryker_Basic", FleetMemberType.SHIP, "Asteroid Cracker", false);
		api.addToFleet(FleetSide.ENEMY, "ryker_Basic", FleetMemberType.SHIP, "Asteroid Cracker", false);
		api.addToFleet(FleetSide.ENEMY, "gemini_Standard", FleetMemberType.SHIP, "Mobile Processing Base", false);
		api.addToFleet(FleetSide.ENEMY, "tarsus_Standard", FleetMemberType.SHIP, "Mining Freighter", false).getCaptain().setPersonality(Personalities.AGGRESSIVE);
		api.addToFleet(FleetSide.ENEMY, "tarsus_Standard", FleetMemberType.SHIP, "Mining Freighter", false).getCaptain().setPersonality(Personalities.AGGRESSIVE);


		// Set up the map.
		float width = 5000f;
		float height = 5000f;
		api.initMap((float)-width/1f, (float)width/1f, (float)-height/1f, (float)height/1f);
		
		float minX = -width/1;
		float minY = -height/1;
		
		api.addNebula(minX + width * 1.0f, minY + height * 0.9f, 6000);

		api.addAsteroidField(minY, minY, 45, 4000f,
								75f, 250f, 250);

		api.addObjective(minX + width * 1.0f, minY + height * 1.0f, "sensor_array");

	}

}
