package data.missions.chargeofthecentaur;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

public class MissionDefinition implements MissionDefinitionPlugin {

	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets
		api.initFleet(FleetSide.PLAYER, "Your Ship", FleetGoal.ATTACK, false);
		api.initFleet(FleetSide.ENEMY, "TTS Armada", FleetGoal.ATTACK, true, 5);

		// Set a blurb for each fleet
		api.setFleetTagline(FleetSide.PLAYER, "Centaur Taskforce");
		api.setFleetTagline(FleetSide.ENEMY, "TTS Armada");

		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("Engage and destroy all TTS ships");
		api.addBriefingItem("Keep the Centaur in one piece");
		api.addBriefingItem("Keep the Damocles in one piece");
	
		// Set up the player's fleet
		api.addToFleet(FleetSide.PLAYER, "centaur_Basic", FleetMemberType.SHIP, "The Centaur", true);
		api.addToFleet(FleetSide.PLAYER, "damocles_Basic", FleetMemberType.SHIP, "The Damocles", false);
		api.addToFleet(FleetSide.PLAYER, "mace_Basic", FleetMemberType.SHIP, "ISS Horizon", false);
		api.addToFleet(FleetSide.PLAYER, "foxhound_Basic", FleetMemberType.SHIP, "The Foxhound", false);
		api.addToFleet(FleetSide.PLAYER, "talus_Support", FleetMemberType.SHIP, "The Vengeance", false);
		api.addToFleet(FleetSide.PLAYER, "wolf_d_Attack", FleetMemberType.SHIP, "Captured Wolf", false);

		// Mark player flagship as essential
		api.defeatOnShipLoss("The Centaur");
		api.defeatOnShipLoss("The Damocles");

		// Set up the enemy fleet
		api.addToFleet(FleetSide.ENEMY, "astral_Elite", FleetMemberType.SHIP, "TTS Carrier", false);
//		api.addToFleet(FleetSide.ENEMY, "aurora_Balanced", FleetMemberType.SHIP, "TTS Armada Admiral", false);
		api.addToFleet(FleetSide.ENEMY, "medusa_Attack", FleetMemberType.SHIP, "TTS Escort", false);
		api.addToFleet(FleetSide.ENEMY, "wolf_Strike", FleetMemberType.SHIP, "TTS Escort", false);
		api.addToFleet(FleetSide.ENEMY, "tempest_Attack", FleetMemberType.SHIP, "TTS Escort", false);
		api.addToFleet(FleetSide.ENEMY, "hyperion_Attack", FleetMemberType.SHIP, "TTS Escort", false);
//		api.addToFleet(FleetSide.ENEMY, "omen_PD", FleetMemberType.SHIP, "TTS Escort", false);


		// Set up the map.
		float width = 7000f;
		float height = 7000f;
		api.initMap((float)-width/1f, (float)width/1f, (float)-height/1f, (float)height/1f);
		
		float minX = -width/1;
		float minY = -height/1;
		
		api.addPlanet(minX + width * 1.0f, minY + height * 1.0f, 800f, "terran", 800f);

		api.addAsteroidField(minX + width/2f, minY + height/2f, 0, 5000f,
								20f, 40f, 75);

	}

}
