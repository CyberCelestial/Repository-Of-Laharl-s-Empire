package data.missions.sinkingthehood;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

public class MissionDefinition implements MissionDefinitionPlugin {

	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets
		api.initFleet(FleetSide.PLAYER, "Your Ship", FleetGoal.ATTACK, false);
		api.initFleet(FleetSide.ENEMY, "TTS Flagship", FleetGoal.ATTACK, true);

		// Set a blurb for each fleet
		api.setFleetTagline(FleetSide.PLAYER, "Centaur Taskforce");
		api.setFleetTagline(FleetSide.ENEMY, "TTS Flagship");

		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("Destroy the TTS Ho'ud");
		api.addBriefingItem("Keep the Centaur in one piece");
	
		// Set up the player's fleet
		api.addToFleet(FleetSide.PLAYER, "centaur_Basic", FleetMemberType.SHIP, "The Centaur", true);
		api.addToFleet(FleetSide.PLAYER, "damocles_Basic", FleetMemberType.SHIP, "The Damocles", false);
//		api.addToFleet(FleetSide.PLAYER, "redstar_Support", FleetMemberType.SHIP, "The Redstar", false);
		api.addToFleet(FleetSide.PLAYER, "wildebeest_Assault", FleetMemberType.SHIP, "The Wildebeest", false);

		// Mark player flagship as essential
		api.defeatOnShipLoss("The Centaur");

		// Set up the enemy fleet
		api.addToFleet(FleetSide.ENEMY, "odyssey_Balanced", FleetMemberType.SHIP, "TTS Ho'ud", false);
		api.addToFleet(FleetSide.ENEMY, "wolf_PD", FleetMemberType.SHIP, "TTS Prince of Wah'les", false);


		// Set up the map.
		float width = 5000f;
		float height = 5000f;
		api.initMap((float)-width/1f, (float)width/1f, (float)-height/1f, (float)height/1f);
		
		float minX = -width/1;
		float minY = -height/1;
		
		api.addAsteroidField(minX + width/2f, minY + height/2f, 0, 10000f,
								20f, 40f, 75);

	}

}
