package data.missions.rockyroad;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

public class MissionDefinition implements MissionDefinitionPlugin {

	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets
		api.initFleet(FleetSide.PLAYER, "Your Ship", FleetGoal.ATTACK, false);
		api.initFleet(FleetSide.ENEMY, "Mining Outfit", FleetGoal.ATTACK, true);

		// Set a blurb for each fleet
		api.setFleetTagline(FleetSide.PLAYER, "Damocles Taskforce");
		api.setFleetTagline(FleetSide.ENEMY, "Maas Belt Mining Outfit");

		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
		api.addBriefingItem("Destroy the mining ships");
		api.addBriefingItem("Keep your ships in one piece");
		api.addBriefingItem("Take care around those asteroid crackers!");
		
	
		// Set up the player's fleet
		api.addToFleet(FleetSide.PLAYER, "damocles_Basic", FleetMemberType.SHIP, "The Damocles", true);
		api.addToFleet(FleetSide.PLAYER, "foxhound_Basic", FleetMemberType.SHIP, "The Foxhound", false);

		// Mark player flagship as essential
		api.defeatOnShipLoss("The Damocles");
		api.defeatOnShipLoss("The Foxhound");

		// Set up the enemy fleet
		api.addToFleet(FleetSide.ENEMY, "moth_Basic", FleetMemberType.SHIP, "Mining Overseer", false);
		api.addToFleet(FleetSide.ENEMY, "moth_Support", FleetMemberType.SHIP, "Overseer Escort", false);
		api.addToFleet(FleetSide.ENEMY, "ryker_Basic", FleetMemberType.SHIP, "Asteroid Cracker", false);
		api.addToFleet(FleetSide.ENEMY, "ryker_Assault", FleetMemberType.SHIP, "Asteroid Cracker", false);


		// Set up the map.
		float width = 3000f;
		float height = 3000f;
		api.initMap((float)-width/1f, (float)width/1f, (float)-height/1f, (float)height/1f);
		
		float minX = -width/1;
		float minY = -height/1;
		
		api.addNebula(minX + width * 1.0f, minY + height * 1.0f, 4000);

		api.addAsteroidField(minY, minY, 45, 3000f,
								50f, 150f, 200);

	}

}
